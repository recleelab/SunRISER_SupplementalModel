# -*- coding: utf-8 -*-
import numpy as np
from scipy.constants import N_A
import matplotlib.pyplot as plt
from scipy.special import gammaln

def lnbn(n,k):
    if k<=n and k>=0:
        return gammaln(n+1)-gammaln(k+1)-gammaln(n-k+1)
    else:
        return -np.inf

def heatmap(n_mRNA,n_GCN4,n_SL):
    ######################################################
    #constants specifying the disassociation constants, 
    #volume of the cell and diffraction-limited resolution,
    #which need to be modified for orthogonal stem-loops
    #and protein-epitope pairs.
    ######################################################
    KD1 = 0.38e-9 # kd of scFv and SunTag (unit: mol/L)
    KD2 = 1e-9 # kd of pcp and pp7 (unit: mol/L)
    V0 = 1745e-18 # volume of whole cell (unit: m^3)
    V = 020e-21 # volume of Rayleigh criterion (unit: m^3)
    NAV = V*N_A # Avogadro's constant times Rayleigh criterion
    N_2GCN4 = 2*n_GCN4
   ######################################################
   ######################################################
   ###################################################### 
    
    a1min = 1e2 #lower limit for x-axis: scFv-GFP (# molecules)
    a1max = 1e6 #upper limit for x-axis: scFv-GFP (# molecules)
    a2min = 1e2 #lower limit for y-axis: PCP-SunTag (# molecules)
    a2max = 1e6 #upper limit for y-axis: PCP-SunTag (# molecules)
    i0 = 20 #sampling point numbers for x-axis
    j0 = 20 #sampling point numbers for y-axis
    a1wave = [a1min*np.exp((np.log(a1max)-np.log(a1min))*(p/(i0-1))) for p in range(i0)]
    a2wave = [a2min*np.exp((np.log(a2max)-np.log(a2min))*(p/(j0-1))) for p in range(j0)]
    Pk = np.full((N_2GCN4*n_SL+1),0.0)
    MatInt=np.full((i0,j0),0.0)
    MatCV = np.full((i0,j0),0.0)
    MatSNR = np.full((i0,j0),0.0)
    MatBG = np.full((i0,j0),0.0)
    
    for i in range(i0):
        for j in range(j0): 
            n_scFv = a1wave[i]
            n_PCP = a2wave[j]
            c1 = n_scFv/N_A/V0 #concentration of scFv
            c2 = n_PCP/N_A/V0/2 #concentration of PCP
            c3 = n_mRNA/N_A/V0 #concentration of mRNA
            p1=min(1,0.5*(KD1+N_2GCN4*c2+c1-np.sqrt((KD1+N_2GCN4*c2+c1)**2-4*c1*N_2GCN4*c2))/c2/N_2GCN4) #p. of free PCP
            p2=min(1,0.5*(KD2+n_SL*c3+c2-np.sqrt((KD2+n_SL*c3+c2)**2-4*c2*n_SL*c3))/c3/n_SL) #p. of free mRNA
            Pk = np.full((N_2GCN4*n_SL+1),0.0)
            Psum=0
            GFP_on_mRNA_bar = 0
            GFP_on_mRNA_var = 0
            for k in range(N_2GCN4*n_SL+1):
                Ptemp=0
                for m in range(n_SL+1):
                    Ptemp+=np.exp(lnbn(n_SL,m)+lnbn(m*N_2GCN4,k)+m*np.log(p2/(1-p2))+\
                          m*N_2GCN4*np.log(1-p1)+n_SL*np.log(1-p2)+k*np.log(p1/(1-p1)))
                Pk[k]=Ptemp
                Psum+=Pk[k]
                GFP_on_mRNA_bar+=Pk[k]*k
                GFP_on_mRNA_var+=Pk[k]*k*k
   
            GFP_on_mRNA_sd=np.sqrt(GFP_on_mRNA_var-GFP_on_mRNA_bar**2)
            background=max(0,NAV*(c1-N_2GCN4*p1*c2))+N_2GCN4*p1*max(0,NAV*(c2-n_SL*p2*c3))
            MatInt[j][i] = np.log10(GFP_on_mRNA_bar)
            MatCV[j][i] = GFP_on_mRNA_sd/GFP_on_mRNA_bar
            MatSNR[j][i] = np.log10(GFP_on_mRNA_bar/background)
            MatBG[j][i] = background
        print(".")
        
    #save data into txt files
    #different rows correspond to different number of PCP-SunTag molecules
    #and different columns correspond to different number of scFv-GFP molecules 
    np.savetxt('Intensity.txt', MatInt) #Intensity for each sampling parameter pair
    np.savetxt('CV.txt', MatCV) #CV for each sampling parameter pair
    np.savetxt('SNR.txt', MatSNR) #SNR for each sampling parameter pair
    np.savetxt('Background.txt', MatBG) #Background for each sampling parameter pair
    
    a1wave_txt = ['{:.2e}'.format(x) for x in a1wave]
    a1wave_txt = ['{:.2e}'.format(x) for x in a2wave]
    
    fig, ax = plt.subplots()
    im = ax.imshow(MatInt,cmap="seismic",vmin=0.0, vmax=3.0)
    cbar = ax.figure.colorbar(im, ax=ax, )
    ax.set_ylim(-0.5,i0-0.5)
    ax.set_xticks(np.arange(i0))
    ax.set_yticks(np.arange(j0))
    ax.set_xticklabels(a1wave_txt,rotation=60)
    ax.set_yticklabels(a1wave_txt)
    cbar.ax.set_ylabel('log intensity (AU)', rotation=-90, va="bottom")
    plt.xlabel(" scFv-GFP (# molecules)")
    plt.ylabel(" PCP-SunTag (# molecules)")
    plt.savefig('Intensity.png', dpi = 300)
    plt.show()
    
    fig, ax = plt.subplots()
    im = ax.imshow(MatCV,cmap="seismic",vmin=0.0, vmax=16.0)
    cbar = ax.figure.colorbar(im, ax=ax, )
    ax.set_ylim(-0.5,i0-0.5)
    ax.set_xticks(np.arange(i0))
    ax.set_yticks(np.arange(j0))
    ax.set_xticklabels(a1wave_txt,rotation=60)
    ax.set_yticklabels(a1wave_txt)
    cbar.ax.set_ylabel('CV', rotation=-90, va="bottom")
    plt.xlabel(" scFv-GFP (# molecules)")
    plt.ylabel(" PCP-SunTag (# molecules)")
    plt.savefig('CV.png', dpi = 300)
    plt.show()
    
    fig, ax = plt.subplots()
    im = ax.imshow(MatSNR,cmap="seismic",vmin=0.0, vmax=6.0)
    cbar = ax.figure.colorbar(im, ax=ax, )
    ax.set_ylim(-0.5,i0-0.5)
    ax.set_xticks(np.arange(i0))
    ax.set_yticks(np.arange(j0))
    ax.set_xticklabels(a1wave_txt,rotation=60)
    ax.set_yticklabels(a1wave_txt)
    cbar.ax.set_ylabel('log signal to noise ratio', rotation=-90, va="bottom")
    plt.xlabel(" scFv-GFP (# molecules)")
    plt.ylabel(" PCP-SunTag (# molecules)")
    plt.savefig('SNR.png', dpi = 300)
    plt.show()
    
    fig, ax = plt.subplots()
    im = ax.imshow(MatBG,cmap="seismic",vmin=0.0, vmax=12.0)
    cbar = ax.figure.colorbar(im, ax=ax, )
    ax.set_ylim(-0.5,i0-0.5)
    ax.set_xticks(np.arange(i0))
    ax.set_yticks(np.arange(j0))
    ax.set_xticklabels(a1wave_txt,rotation=60)
    ax.set_yticklabels(a1wave_txt)
    cbar.ax.set_ylabel('Background', rotation=-90, va="bottom")
    plt.xlabel(" scFv-GFP (# molecules)")
    plt.ylabel(" PCP-SunTag (# molecules)")
    plt.savefig('Background.png', dpi = 300)
    plt.show()
    
######################################################
#Input specifying the number of stem-loops, 
#the number of GCN4 peptides and the number of mRNA molecules
######################################################
n_GCN4 = 10 #number of SunTag binding sites on PCP
n_SL = 24 #number of stem-loop binding sites on mRNA
n_mRNA = 100 #numbers of mRNAs molecules
######################################################
######################################################
######################################################
heatmap(n_mRNA,n_GCN4,n_SL)