# -*- coding: utf-8 -*-
import numpy as np
from scipy.constants import N_A
import matplotlib.pyplot as plt
from scipy.special import gammaln

def lnbn(n,k):
    if k<=n and k>=0:
        return gammaln(n+1)-gammaln(k+1)-gammaln(n-k+1)
    else:
        return -np.inf

def calculate_gfp_numbers(n_scFv,n_PCP,n_mRNA,n_GCN4,n_SL): 
    ######################################################
    #constants specifying the disassociation constants, 
    #volume of the cell and diffraction-limited resolution,
    #which need to be modified for orthogonal stem-loops
    #and protein-epitope pairs.
    ######################################################
    KD1 = 0.38e-9 # kd of scFv and SunTag (unit: mol/L)
    KD2 = 1e-9 # kd of pcp and pp7 (unit: mol/L)
    V0 = 1745e-18 # volume of whole cell (unit: m^3)
    V = 020e-21 # volume of Rayleigh criterion (unit: m^3)
    NAV = V*N_A # Avogadro's constant times Rayleigh criterion
    N_2GCN4 = 2*n_GCN4
    #######################################################
    #######################################################
    #######################################################
    #Calculation
    c1 = n_scFv/N_A/V0 #concentration of scFv
    c2 = n_PCP/N_A/V0/2 #concentration of PCP
    c3 = n_mRNA/N_A/V0 #concentration of mRNA
    p1=min(1,0.5*(KD1+N_2GCN4*c2+c1-np.sqrt((KD1+N_2GCN4*c2+c1)**2-4*c1*N_2GCN4*c2))/c2/N_2GCN4) #p. of free PCP
    p2=min(1,0.5*(KD2+n_SL*c3+c2-np.sqrt((KD2+n_SL*c3+c2)**2-4*c2*n_SL*c3))/c3/n_SL) #p. of free mRNA
    Pk = np.full((N_2GCN4*n_SL+1),0.0)
    Psum=0.0
    GFP_on_mRNA_bar = 0.0
    GFP_on_mRNA_var = 0.0
    for k in range(N_2GCN4*n_SL+1):
        Ptemp=0.0
        for m in range(n_SL+1):
            Ptemp+=np.exp(lnbn(n_SL,m)+lnbn(m*N_2GCN4,k)+m*np.log(p2/(1-p2))+\
                          m*N_2GCN4*np.log(1-p1)+n_SL*np.log(1-p2)+k*np.log(p1/(1-p1)))
        Pk[k]=Ptemp
        Psum+=Pk[k]
        GFP_on_mRNA_bar+=Pk[k]*k
        GFP_on_mRNA_var+=Pk[k]*k*k
   
    GFP_on_mRNA_sd=np.sqrt(GFP_on_mRNA_var-GFP_on_mRNA_bar**2)
    background=max(0,NAV*(c1-N_2GCN4*p1*c2))+N_2GCN4*p1*max(0,NAV*(c2-n_SL*p2*c3)) #background
    
    params = [Psum,GFP_on_mRNA_bar,GFP_on_mRNA_sd,background]
    return (params,N_2GCN4*n_SL,Pk)

######################################################
#Input specifying the number of stem-loops, 
#the number of GCN4 peptides, the parameter pairs of
#(GFP molecules, PCP molecules) and a set of mRNA
#molecule numbers
######################################################
GFP_PCP_list=[(500000,100000),(50000,10000),(5000,1000),(300000,300000),(10000,10000),\
                (300,300),(100000,500000),(10000,50000),(1000,5000),(100000,4000)]
mRNA_list= [1,10,100,1000,10000]
n_GCN4 = 10 #number of SunTag binding sites on PCP
n_SL = 24 #number of stem-loop binding sites on mRNA
######################################################
######################################################
######################################################

#Plotting
x_gfp = np.arange(2*n_GCN4*n_SL+1)
for point in GFP_PCP_list:
    #single figure
    fig, ax = plt.subplots()
    x_gfp = np.arange(2*n_GCN4*n_SL+1)
    baseline = np.full((2*n_GCN4*n_SL+1),0)
    
    colorlist1=['red','darkorange','limegreen','royalblue','darkviolet']
    colorlist2=['lightsalmon','moccasin','lightgreen','lightskyblue','plum']
    j=0.0
    for i,N_RNA in enumerate(mRNA_list):
        params,Npnts,p_gfp = calculate_gfp_numbers(point[0],point[1],N_RNA,n_GCN4,n_SL)
        #save data into txt files, the first column is number of GFP molecules 
        #and the second column is the probability value
        np.savetxt('histogram_n_GFP_'+'{:.2e}'.format(point[0])+'_n_PCP_'+'{:.2e}'.format(point[1])+'.txt', np.vstack((x_gfp,p_gfp)).T)
        ax.plot(x_gfp,p_gfp+j,linewidth =2.5,color=colorlist1[i])
        ax.fill_between(x_gfp, p_gfp+j, baseline+j,color = colorlist2[i])
        j+=0.04
        print('.')
    for axis in ['top','bottom','left','right']:
        ax.spines[axis].set_linewidth(2)
    ax.xaxis.set_tick_params(width=2)
    ax.yaxis.set_tick_params(width=2)
    ax.xaxis.set_tick_params(length=6)
    ax.yaxis.set_tick_params(length=6)
    ax.tick_params(axis='x', labelsize= 20)
    ax.tick_params(axis='y', labelsize= 20)
    ax.set_xticks([0,500])
    ax.set_yticks([0.0,0.1,0.2])
    ax.set_ylim(0,0.25)
    plt.xlabel(" GFP per mRNA (# molecules)")
    plt.ylabel("Probability")
    plt.title('scFv-GFP : PCP-SunTag = '+str(point[0])+':'+str(point[1]))
    plt.savefig('result_'+str(point[0])+'_'+str(point[1])+'.png', dpi = 300)
    plt.show() 
    

